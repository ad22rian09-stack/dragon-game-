
  # Daily Progress Screen

  This is a code bundle for Daily Progress Screen. The original project is available at https://www.figma.com/design/zBE9CHD535qu5CLqxml5iC/Daily-Progress-Screen.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  