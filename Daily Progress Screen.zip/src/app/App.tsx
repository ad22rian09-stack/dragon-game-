import { useState } from "react";
import { ProfileHeader } from "./components/study/ProfileHeader";
import { DailyMissions, Mission } from "./components/study/DailyMissions";
import { StudyStats } from "./components/study/StudyStats";
import { SubjectProgress, Subject } from "./components/study/SubjectProgress";
import { WeeklyProgress } from "./components/study/WeeklyProgress";
import { ColorPicker } from "./components/study/ColorPicker";
import { Menu, Bell, Palette } from "lucide-react";

export default function App() {
  const [backgroundColor, setBackgroundColor] = useState("bg-gray-200");
  const [showColorPicker, setShowColorPicker] = useState(false);
  
  const [missions, setMissions] = useState<Mission[]>([
    {
      id: "1",
      title: "Study for 30 minutes",
      description: "Complete a focused study session",
      xpReward: 50,
      completed: true,
      progress: 30,
      total: 30,
    },
    {
      id: "2",
      title: "Complete 10 practice problems",
      description: "Practice makes perfect",
      xpReward: 100,
      completed: false,
      progress: 7,
      total: 10,
    },
    {
      id: "3",
      title: "Review yesterday's notes",
      description: "Reinforce your learning",
      xpReward: 30,
      completed: false,
      progress: 0,
      total: 1,
    },
    {
      id: "4",
      title: "Watch 2 educational videos",
      description: "Expand your knowledge",
      xpReward: 40,
      completed: false,
      progress: 1,
      total: 2,
    },
  ]);

  const handleToggleMission = (id: string) => {
    setMissions(missions.map(mission =>
      mission.id === id ? { ...mission, completed: !mission.completed } : mission
    ));
  };

  const stats = [
    { label: "Study Time", value: "2h 15m", icon: "clock" as const, color: "bg-blue-500" },
    { label: "Sessions", value: "4", icon: "book" as const, color: "bg-purple-500" },
    { label: "XP Today", value: "250", icon: "target" as const, color: "bg-amber-500" },
    { label: "Streak", value: "7 days", icon: "trending" as const, color: "bg-green-500" },
  ];

  const subjects: Subject[] = [
    {
      id: "1",
      name: "Mathematics",
      icon: "📐",
      timeStudied: 45,
      goal: 60,
      color: "bg-blue-100",
    },
    {
      id: "2",
      name: "Physics",
      icon: "⚛️",
      timeStudied: 30,
      goal: 45,
      color: "bg-purple-100",
    },
    {
      id: "3",
      name: "Literature",
      icon: "📚",
      timeStudied: 60,
      goal: 60,
      color: "bg-green-100",
    },
  ];

  const weeklyProgress = [
    { day: "Mon", completed: true, isToday: false, xpEarned: 180 },
    { day: "Tue", completed: true, isToday: false, xpEarned: 220 },
    { day: "Wed", completed: true, isToday: false, xpEarned: 150 },
    { day: "Thu", completed: true, isToday: true, xpEarned: 250 },
    { day: "Fri", completed: false, isToday: false, xpEarned: 0 },
    { day: "Sat", completed: false, isToday: false, xpEarned: 0 },
    { day: "Sun", completed: false, isToday: false, xpEarned: 0 },
  ];

  return (
    <div className={`min-h-screen ${backgroundColor}`}>
      {/* Top Navigation */}
      <div className="bg-white border-b border-gray-200 px-6 py-4 sticky top-0 z-10">
        <div className="flex items-center justify-between max-w-md mx-auto">
          <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <Menu className="w-6 h-6 text-gray-600" />
          </button>
          <h1 className="text-lg font-semibold text-gray-800">My Progress</h1>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setShowColorPicker(true)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              title="Change background color"
            >
              <Palette className="w-6 h-6 text-gray-600" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors relative">
              <Bell className="w-6 h-6 text-gray-600" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-md mx-auto px-6 py-6 space-y-6 pb-24">
        <ProfileHeader
          level={12}
          currentXP={750}
          xpToNextLevel={1000}
          streak={7}
        />

        <StudyStats stats={stats} />

        <DailyMissions missions={missions} onToggleMission={handleToggleMission} />

        <SubjectProgress subjects={subjects} />

        <WeeklyProgress days={weeklyProgress} />
      </div>

      {/* Color Picker Modal */}
      {showColorPicker && (
        <ColorPicker
          selectedColor={backgroundColor}
          onColorChange={setBackgroundColor}
          onClose={() => setShowColorPicker(false)}
        />
      )}

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 py-4">
        <div className="max-w-md mx-auto flex justify-around">
          <button className="flex flex-col items-center gap-1 text-indigo-600">
            <div className="w-6 h-6">📊</div>
            <span className="text-xs font-semibold">Progress</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-gray-500 hover:text-gray-700 transition-colors">
            <div className="w-6 h-6">📖</div>
            <span className="text-xs font-medium">Study</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-gray-500 hover:text-gray-700 transition-colors">
            <div className="w-6 h-6">🏆</div>
            <span className="text-xs font-medium">Achievements</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-gray-500 hover:text-gray-700 transition-colors">
            <div className="w-6 h-6">👤</div>
            <span className="text-xs font-medium">Profile</span>
          </button>
        </div>
      </div>
    </div>
  );
}