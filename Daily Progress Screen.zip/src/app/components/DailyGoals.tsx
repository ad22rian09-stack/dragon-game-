import { CheckCircle2, Circle } from "lucide-react";
import { Card } from "./ui/card";
import { Progress } from "./ui/progress";

interface Goal {
  id: string;
  title: string;
  completed: boolean;
}

interface DailyGoalsProps {
  goals: Goal[];
  onToggleGoal: (id: string) => void;
}

export function DailyGoals({ goals, onToggleGoal }: DailyGoalsProps) {
  const completedCount = goals.filter(g => g.completed).length;
  const progress = (completedCount / goals.length) * 100;

  return (
    <Card className="p-6">
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-lg font-semibold">Today's Goals</h2>
          <span className="text-sm text-gray-500">{completedCount}/{goals.length}</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>
      
      <div className="space-y-3">
        {goals.map((goal) => (
          <button
            key={goal.id}
            onClick={() => onToggleGoal(goal.id)}
            className="w-full flex items-center gap-3 text-left transition-opacity hover:opacity-70"
          >
            {goal.completed ? (
              <CheckCircle2 className="w-6 h-6 text-green-500 flex-shrink-0" />
            ) : (
              <Circle className="w-6 h-6 text-gray-300 flex-shrink-0" />
            )}
            <span className={goal.completed ? "line-through text-gray-400" : ""}>
              {goal.title}
            </span>
          </button>
        ))}
      </div>
    </Card>
  );
}
