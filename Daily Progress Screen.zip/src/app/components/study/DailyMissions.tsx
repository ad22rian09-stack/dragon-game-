import { CheckCircle2, Circle, Coins } from "lucide-react";
import { Card } from "../ui/card";

export interface Mission {
  id: string;
  title: string;
  description: string;
  xpReward: number;
  completed: boolean;
  progress: number;
  total: number;
}

interface DailyMissionsProps {
  missions: Mission[];
  onToggleMission: (id: string) => void;
}

export function DailyMissions({ missions, onToggleMission }: DailyMissionsProps) {
  const completedCount = missions.filter(m => m.completed).length;

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-800">Daily Missions</h3>
        <span className="text-sm text-gray-500 font-medium">{completedCount}/{missions.length}</span>
      </div>

      <div className="space-y-3">
        {missions.map((mission) => (
          <Card
            key={mission.id}
            className={`p-4 transition-all ${
              mission.completed ? "bg-green-50 border-green-200" : "bg-white"
            }`}
          >
            <div className="flex items-start gap-3">
              <button
                onClick={() => onToggleMission(mission.id)}
                className="mt-1 transition-transform hover:scale-110"
              >
                {mission.completed ? (
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                ) : (
                  <Circle className="w-6 h-6 text-gray-300" />
                )}
              </button>
              
              <div className="flex-1">
                <div className="flex items-start justify-between mb-1">
                  <h4 className={`font-medium ${mission.completed ? "text-gray-500 line-through" : "text-gray-800"}`}>
                    {mission.title}
                  </h4>
                  <div className="flex items-center gap-1 bg-amber-100 text-amber-700 px-2 py-1 rounded-full text-xs font-semibold">
                    <Coins className="w-3 h-3" />
                    {mission.xpReward} XP
                  </div>
                </div>
                <p className="text-sm text-gray-600">{mission.description}</p>
                
                {!mission.completed && mission.total > 1 && (
                  <div className="mt-2">
                    <div className="flex items-center justify-between text-xs text-gray-600 mb-1 font-medium">
                      <span>Progress</span>
                      <span>{mission.progress}/{mission.total}</span>
                    </div>
                    <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-indigo-500 transition-all duration-300"
                        style={{ width: `${(mission.progress / mission.total) * 100}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}