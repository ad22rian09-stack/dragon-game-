import { Clock, BookOpen, Target, TrendingUp } from "lucide-react";
import { Card } from "../ui/card";

interface Stat {
  label: string;
  value: string;
  icon: "clock" | "book" | "target" | "trending";
  color: string;
}

interface StudyStatsProps {
  stats: Stat[];
}

const iconMap = {
  clock: Clock,
  book: BookOpen,
  target: Target,
  trending: TrendingUp,
};

export function StudyStats({ stats }: StudyStatsProps) {
  return (
    <div>
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Today's Stats</h3>
      <div className="grid grid-cols-2 gap-3">
        {stats.map((stat, index) => {
          const Icon = iconMap[stat.icon];
          return (
            <Card key={index} className="p-4 shadow-sm">
              <div className={`w-10 h-10 rounded-xl ${stat.color} flex items-center justify-center mb-3`}>
                <Icon className="w-5 h-5 text-white" />
              </div>
              <p className="text-2xl font-semibold text-gray-800 mb-1">{stat.value}</p>
              <p className="text-sm text-gray-600">{stat.label}</p>
            </Card>
          );
        })}
      </div>
    </div>
  );
}