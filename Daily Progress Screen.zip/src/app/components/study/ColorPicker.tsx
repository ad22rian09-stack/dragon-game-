import { Card } from "../ui/card";
import { Check } from "lucide-react";

interface ColorPickerProps {
  selectedColor: string;
  onColorChange: (color: string) => void;
  onClose: () => void;
}

const colors = [
  { name: "Light Gray", value: "bg-gray-200", hex: "#E5E7EB" },
  { name: "White", value: "bg-white", hex: "#FFFFFF" },
  { name: "Slate", value: "bg-slate-100", hex: "#F1F5F9" },
  { name: "Blue", value: "bg-blue-50", hex: "#EFF6FF" },
  { name: "Green", value: "bg-green-50", hex: "#F0FDF4" },
  { name: "Purple", value: "bg-purple-50", hex: "#FAF5FF" },
  { name: "Pink", value: "bg-pink-50", hex: "#FDF2F8" },
  { name: "Yellow", value: "bg-yellow-50", hex: "#FEFCE8" },
  { name: "Orange", value: "bg-orange-50", hex: "#FFF7ED" },
  { name: "Indigo", value: "bg-indigo-50", hex: "#EEF2FF" },
  { name: "Teal", value: "bg-teal-50", hex: "#F0FDFA" },
  { name: "Dark", value: "bg-gray-800", hex: "#1F2937" },
];

export function ColorPicker({ selectedColor, onColorChange, onClose }: ColorPickerProps) {
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <Card className="w-full max-w-sm p-6 shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="mb-4">
          <h3 className="text-lg font-semibold text-gray-800 mb-1">Choose Background Color</h3>
          <p className="text-sm text-gray-600">Select your preferred background</p>
        </div>

        <div className="grid grid-cols-4 gap-3 mb-4">
          {colors.map((color) => (
            <button
              key={color.value}
              onClick={() => onColorChange(color.value)}
              className="relative group"
            >
              <div
                className={`w-full aspect-square rounded-xl border-2 transition-all ${
                  selectedColor === color.value
                    ? "border-indigo-500 scale-95"
                    : "border-gray-200 hover:border-gray-300"
                } ${color.value}`}
                style={{ backgroundColor: color.hex }}
              >
                {selectedColor === color.value && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="bg-indigo-500 rounded-full p-1">
                      <Check className="w-4 h-4 text-white" />
                    </div>
                  </div>
                )}
              </div>
              <p className="text-xs text-gray-700 mt-1 text-center font-medium">{color.name}</p>
            </button>
          ))}
        </div>

        <button
          onClick={onClose}
          className="w-full bg-indigo-600 text-white py-2.5 rounded-lg font-semibold hover:bg-indigo-700 transition-colors"
        >
          Done
        </button>
      </Card>
    </div>
  );
}