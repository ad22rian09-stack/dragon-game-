import { Trophy, Flame } from "lucide-react";
import { Progress } from "../ui/progress";

interface ProfileHeaderProps {
  level: number;
  currentXP: number;
  xpToNextLevel: number;
  streak: number;
}

export function ProfileHeader({ level, currentXP, xpToNextLevel, streak }: ProfileHeaderProps) {
  const xpProgress = (currentXP / xpToNextLevel) * 100;

  return (
    <div className="bg-gradient-to-br from-[#4CAF50] to-[#388E3C] text-white p-6 rounded-3xl shadow-lg">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h2 className="text-2xl font-semibold">Study Tracker</h2>
          <p className="text-sm text-white/90">Keep learning every day!</p>
        </div>
        <div className="bg-white/20 backdrop-blur-sm rounded-full px-4 py-2 flex items-center gap-2">
          <Flame className="w-5 h-5 text-orange-300" />
          <span className="font-semibold">{streak}</span>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="bg-white/20 backdrop-blur-sm rounded-2xl w-16 h-16 flex items-center justify-center">
          <Trophy className="w-8 h-8 text-yellow-300" />
        </div>
        <div className="flex-1">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Level {level}</span>
            <span className="text-sm text-white/90">{currentXP} / {xpToNextLevel} XP</span>
          </div>
          <Progress value={xpProgress} className="h-3 bg-white/20" />
        </div>
      </div>
    </div>
  );
}