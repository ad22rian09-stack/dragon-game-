import { Card } from "../ui/card";
import { Progress } from "../ui/progress";

export interface Subject {
  id: string;
  name: string;
  icon: string;
  timeStudied: number;
  goal: number;
  color: string;
}

interface SubjectProgressProps {
  subjects: Subject[];
}

export function SubjectProgress({ subjects }: SubjectProgressProps) {
  return (
    <div>
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Study Sessions</h3>
      <div className="space-y-3">
        {subjects.map((subject) => {
          const progress = (subject.timeStudied / subject.goal) * 100;
          const isComplete = subject.timeStudied >= subject.goal;
          
          return (
            <Card key={subject.id} className="p-4 shadow-sm">
              <div className="flex items-center gap-3 mb-3">
                <div className={`w-10 h-10 rounded-xl ${subject.color} flex items-center justify-center text-xl`}>
                  {subject.icon}
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-gray-800">{subject.name}</h4>
                  <p className="text-sm text-gray-600">
                    {subject.timeStudied} / {subject.goal} min
                  </p>
                </div>
                {isComplete && (
                  <div className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-semibold">
                    Complete
                  </div>
                )}
              </div>
              <Progress value={Math.min(progress, 100)} className="h-2" />
            </Card>
          );
        })}
      </div>
    </div>
  );
}