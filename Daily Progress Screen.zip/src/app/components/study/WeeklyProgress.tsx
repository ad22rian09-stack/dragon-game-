import { Card } from "../ui/card";

interface DayProgress {
  day: string;
  completed: boolean;
  isToday: boolean;
  xpEarned: number;
}

interface WeeklyProgressProps {
  days: DayProgress[];
}

export function WeeklyProgress({ days }: WeeklyProgressProps) {
  return (
    <div>
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Weekly Streak</h3>
      <Card className="p-4 shadow-sm">
        <div className="flex justify-between gap-2">
          {days.map((day, index) => (
            <div key={index} className="flex flex-col items-center gap-2 flex-1">
              <span className="text-xs text-gray-600 font-medium">{day.day}</span>
              <div
                className={`w-full aspect-square rounded-xl flex items-center justify-center text-sm font-semibold transition-all ${
                  day.isToday
                    ? "bg-indigo-500 text-white ring-2 ring-indigo-200 scale-110"
                    : day.completed
                    ? "bg-green-500 text-white"
                    : "bg-gray-100 text-gray-400"
                }`}
              >
                {day.completed ? "✓" : ""}
              </div>
              {day.xpEarned > 0 && (
                <span className="text-xs text-gray-500 font-medium">{day.xpEarned} XP</span>
              )}
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}