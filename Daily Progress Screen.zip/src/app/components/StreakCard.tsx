import { Flame } from "lucide-react";
import { Card } from "./ui/card";

interface StreakCardProps {
  currentStreak: number;
  bestStreak: number;
}

export function StreakCard({ currentStreak, bestStreak }: StreakCardProps) {
  return (
    <Card className="p-6 bg-gradient-to-br from-orange-500 to-red-500 text-white border-0">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm opacity-90 mb-1">Current Streak</p>
          <div className="flex items-baseline gap-2">
            <span className="text-5xl font-bold">{currentStreak}</span>
            <span className="text-xl opacity-90">days</span>
          </div>
        </div>
        <div className="bg-white/20 rounded-full p-4">
          <Flame className="w-12 h-12" />
        </div>
      </div>
      <div className="mt-4 pt-4 border-t border-white/20">
        <p className="text-sm opacity-90">Best Streak: <span className="font-semibold">{bestStreak} days</span></p>
      </div>
    </Card>
  );
}
