import { Card } from "./ui/card";

interface DayStatus {
  date: number;
  label: string;
  completed: boolean;
  isToday: boolean;
}

interface WeekCalendarProps {
  days: DayStatus[];
}

export function WeekCalendar({ days }: WeekCalendarProps) {
  return (
    <Card className="p-6">
      <h2 className="text-lg font-semibold mb-4">This Week</h2>
      <div className="grid grid-cols-7 gap-2">
        {days.map((day, index) => (
          <div key={index} className="flex flex-col items-center gap-2">
            <span className="text-xs text-gray-500">{day.label}</span>
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium transition-all ${
                day.isToday
                  ? "bg-blue-500 text-white ring-2 ring-blue-200"
                  : day.completed
                  ? "bg-green-500 text-white"
                  : "bg-gray-100 text-gray-400"
              }`}
            >
              {day.date}
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
