import { TrendingUp, Target, Award } from "lucide-react";
import { Card } from "./ui/card";

interface Stat {
  label: string;
  value: string;
  icon: "trending" | "target" | "award";
  color: string;
}

interface StatsCardProps {
  stats: Stat[];
}

const iconMap = {
  trending: TrendingUp,
  target: Target,
  award: Award,
};

export function StatsCard({ stats }: StatsCardProps) {
  return (
    <div className="grid grid-cols-3 gap-3">
      {stats.map((stat, index) => {
        const Icon = iconMap[stat.icon];
        return (
          <Card key={index} className="p-4">
            <div className={`w-8 h-8 rounded-lg ${stat.color} flex items-center justify-center mb-2`}>
              <Icon className="w-4 h-4 text-white" />
            </div>
            <p className="text-xs text-gray-500 mb-1">{stat.label}</p>
            <p className="text-lg font-semibold">{stat.value}</p>
          </Card>
        );
      })}
    </div>
  );
}
